<script>

export default {
  name : 'About',
};
</script>

<template>
</template>

<style scoped>
*{
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}
</style>
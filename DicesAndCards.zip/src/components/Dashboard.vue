<script>
export default {
  name: 'Dashboard'
}
</script>

<template>
  This is my Admin Dashboard
</template>

<style scoped>
*{
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}
</style>